<?php
//required to use WP. Set to false when using from Unity. Set to true when using in WP.
//In unity we will pass in a "Unity" field so let's test for that now...
$unity = isset($REQUEST['unity']);

//I force WUSSACTION to 'wuss' if no action was specified to prevent the execution of external code
define('WP_USE_THEMES', !isSet($unity) ? true : false );
define('CALLED_FROM_GAME', WP_USE_THEMES == false ? true : false);
define('WUSSACTION', isSet( $_REQUEST['wuss'] ) ? strtolower( trim( $_REQUEST['wuss'] ) ) : 'wuss');
define('ACTION', WUSSACTION . (isset($_REQUEST['action']) ? $_REQUEST['action'] : '') );
if (!CALLED_FROM_GAME || WUSSACTION == ACTION) die();

//this kit is intended to be installed in wp-content/plugins/wuss_login
//so we need to go back 3 folders to find this file. Adjust as necesarry
require_once( dirname(__FILE__) . '/../../../wp-load.php' );
//require_once( ABSPATH . 'wp-admin/includes/admin.php' );
//require_once( ABSPATH . 'wp-admin/includes/ajax-actions.php' );

@header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
@header( 'X-Robots-Tag: noindex' );

send_origin_headers();
send_nosniff_header();
nocache_headers();

require_once(dirname(__FILE__) . "/functions.php");

function wuss_autoloader($class) {
    include 'classes/'. $class . '.class.php';
}
spl_autoload_register('wuss_autoloader');


if (function_exists(ACTION))
{
	$logged_out_functions = array('loginDoLogin', 'loginSubmitRegistration','loginVerifyLogin','loginPasswordReset');
	
	if (in_array( ACTION, $logged_out_functions ) && !is_user_logged_in())
	{
		add_action( "wp_ajax_nopriv_".ACTION, ACTION, 1 );
		do_action( 'wp_ajax_nopriv_' . ACTION );
	} else
	{
		add_action( "wp_ajax_".ACTION, ACTION, 1 );
		do_action( 'wp_ajax_' . ACTION.'' );
	}
}
die();
